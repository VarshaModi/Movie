﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Web;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [Route("/api/movies")]
    public class TestController : Controller
    {
        private readonly MovieContext _context;

        public TestController(MovieContext context)
        {
            _context = context;
        }
        /// <summary
        /// </summary>  
        /// <returns></returns>  
        /// 
        [HttpGet]
        public JsonResult Get()
        {
            var moviesList = _context.Movies
                .Include(m => m.Producer);

                return Json(moviesList);
        }
        [HttpGet("{id}")]
        public JsonResult Get(int id)
        {
            //Creates a Movie based on the Title
            //var movie = new Movie();



            var movie = _context.Movies
                 .Include(m => m.Producer)
                 .Include(m => _context.ActorsMovies.Where(x => x.MovieId == id))
                .SingleOrDefault(m => m.Id == id);
               
                //Loading students only
                /* IList<Movie> movList = _context.Movies.ToList<Movie>();
                 Movie mov = movList[id];
             Producer pro = mov.Producer;*/
                //Loads Student address for particular Student only (seperate SQL query)
                // IList<ActorMovieMapping> add =mov.ActorMovie.ToList<ActorMovieMapping>();


          /*  _context.Entry(movie).Reference(m => m.Producer).Load(); // loads StudentAddress
            _context.Entry(movie).Collection(m => m.ActorMovie).Load(); // loads Courses collection
            */
            return Json(movie);
        }
        [HttpPost]
        public JsonResult Add([FromBody]MoviesClass movie)
        {
            //Creates a Movie based on the Title
            // do stuff
            var m = new Movie();
            m.Id = movie.Id;
            m.Name = movie.Name;
            m.Language = movie.Language;
            m.ReleasedDate = movie.ReleasedDate;
            m.ProducerId = movie.ProducerId;
            _context.Movies.Add(m);
            _context.SaveChangesAsync();
            foreach (var actorId in movie.ActorIds)
            {
                _context.ActorsMovies.Add(new ActorMovieMapping
                {
                    ActorId = actorId,
                    MovieId = m.Id
                });
            }
           
            return Json("Added");
        }

        [HttpPut("{id}")]
        public JsonResult Delete(int id)
        {
            //Creates a Movie based on the Title
            var movie = new Movie();
            movie =_context.Movies.Find(id); 
            _context.Movies.Remove(movie);
            _context.SaveChanges();
            return Json("Deleted");
        }

        [HttpPut]
        public JsonResult Update([FromBody]MoviesClass movie)
        {
            //Creates a Movie based on the Title
            var m = new Movie();
            m.Id = movie.Id;
            m.Name = movie.Name;
            m.Language = movie.Language;
            m.ReleasedDate = movie.ReleasedDate;
            m.ProducerId = movie.ProducerId;
            _context.Movies.Update(m);
            _context.SaveChanges();
            return Json("Updated");
        }
    }
}