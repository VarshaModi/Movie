﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using System.Web;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [Route("/api/producers")]
    public class ProducerController : Controller
        {
            private readonly MovieContext _context;

            public ProducerController(MovieContext context)
            {
                _context = context;
            }

       

        [HttpGet]
        public JsonResult Get()
        {
            var producerList = _context.Producers;
            return Json(producerList);
        }
        [HttpGet("{id}")]
        public JsonResult Get(int id)
        {
            var producer = new Producer();
            producer = _context.Producers.Find(id);
            return Json(producer);
        }

        [HttpPost]
        public JsonResult Add([FromBody]Producer producer)
        {
            //Creates a Producer
            // do stuff
            _context.Producers.Add(producer);
            _context.SaveChanges();
            return Json("Added");
        }

        [HttpPut("{id}")]
        public JsonResult Delete(int id)
        {
            var producer = new Producer();
            producer = _context.Producers.Find(id);
            _context.Producers.Remove(producer);
            _context.SaveChanges();
            return Json("Deleted");

        }

        [HttpPut]
        public JsonResult Update([FromBody]Producer producer)
        {
            //Creates a Movie based on the Title
            _context.Producers.Update(producer);
            _context.SaveChanges();
            return Json("Updated");
        }

       
    }
}
