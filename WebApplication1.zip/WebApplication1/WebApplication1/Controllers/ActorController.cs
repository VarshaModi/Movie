﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using System.Web;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Controllers
{
    [Route("/api/actors")]
    public class ActorController : Controller
    {
        private readonly MovieContext _context;

        public ActorController(MovieContext context)
        {
            _context = context;
        }


        [HttpGet]
        public JsonResult Get()
        {
            var actorList = _context.Actors;
            return Json(actorList);
        }
        [HttpGet("{id}")]
        public JsonResult Get(int id)
        {
            var actor = new Actor();
            actor = _context.Actors.Find(id);
            return Json(actor);
        }

        [HttpPost]
        public JsonResult Add([FromBody]Actor actor)
        {
            //Creates a Producer
            // do stuff
            _context.Actors.Add(actor);
            _context.SaveChanges();

            return Json("Added");
        }

        [HttpPut("{id}")]
        public JsonResult Delete(int id)
        {
            var actor = new Actor();
            actor = _context.Actors.Find(id);
            _context.Actors.Remove(actor);
            _context.SaveChanges();
            return Json("Deleted");

        }
        [HttpPut]
        public JsonResult Update([FromBody]Actor actor)
        {
            //Creates a Movie based on the Title
            _context.Actors.Update(actor);
            _context.SaveChanges();
            return Json("Updated");
        }


    }
}
