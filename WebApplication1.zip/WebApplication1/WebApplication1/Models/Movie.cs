﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Movie
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        [Column("Movie")]
        public string Name { get; set; }

        public string Language { get; set; }

        [DataType(DataType.Date)]

        public DateTime ReleasedDate { get; set; }
        public int ProducerId { get; set; }
        public virtual List<ActorMovieMapping> ActorMovie { get; set; }
        public virtual Producer Producer { get; set; }

    }
}


